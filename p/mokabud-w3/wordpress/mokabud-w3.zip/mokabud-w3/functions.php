<?php
/**
 * Motyw Mokabud — wspólna część obu wariantów.
 * Treść strony głównej to zwykła strona WordPressa złożona z bloków:
 * klient edytuje ją w edytorze, a układ i ruch trzyma motyw.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'MOKABUD_VER', '1.0.0' );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_editor_style( 'assets/css/site.css' );
	load_theme_textdomain( 'mokabud', get_template_directory() . '/languages' );
} );

/* Styl i skrypt strony */
add_action( 'wp_enqueue_scripts', function () {
	$dir = get_template_directory_uri();
	wp_enqueue_style( 'mokabud', $dir . '/assets/css/site.css', array(), MOKABUD_VER );
	wp_enqueue_script( 'mokabud', $dir . '/assets/js/site.js', array(), MOKABUD_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
} );

/* Klasa .js zanim cokolwiek się narysuje — bez JS cała treść jest widoczna */
add_action( 'wp_head', function () {
	echo "<script>document.documentElement.classList.add('js')</script>\n";
}, 1 );

/* Lżej: bez emoji i zbędnych nagłówków */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );

require get_template_directory() . '/inc/tresci.php';
require get_template_directory() . '/inc/formularz.php';
require get_template_directory() . '/inc/makieta.php';
require get_template_directory() . '/inc/demo.php';

/* Polska typografia: jednoliterowe spójniki i przyimki nie zostają na końcu wiersza */
add_filter( 'render_block', function ( $html, $block ) {
	if ( ! in_array( $block['blockName'] ?? '', array( 'core/heading', 'core/paragraph', 'core/list-item', 'core/post-title', 'core/post-excerpt' ), true ) ) {
		return $html;
	}
	return preg_replace_callback( '/>([^<]+)</u', function ( $m ) {
		return '>' . preg_replace( '/(^|[\s(„])([aiouwzAIOUWZ])\s+/u', '$1$2&nbsp;', $m[1] ) . '<';
	}, $html );
}, 30, 2 );

/* Duże zdjęcia: przeglądarka bierze plik odpowiedni do szerokości (ekrany retina) */
add_filter( 'wp_calculate_image_sizes', function ( $sizes, $size ) {
	$w = is_array( $size ) ? (int) $size[0] : 0;
	return $w >= 1200 ? '(max-width: 980px) 100vw, 62vw' : $sizes;
}, 10, 2 );
