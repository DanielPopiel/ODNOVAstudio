/* Mokabud — W3 „Plakat”: film z oddaniem kluczy przesuwany przewijaniem, kinetyczny nagłówek, menu. */
(() => {
  const ruchOk = !matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hero = document.querySelector('.mb-hero');

  /* telefon na dole menu mobilnego */
  document.querySelectorAll('.mb-nav .wp-block-navigation__responsive-container-content').forEach(c => {
    const a = document.createElement('a');
    a.className = 'mb-menu-tel'; a.href = 'tel:+48502908270';
    a.innerHTML = '<small>Zadzwoń, Tobiasz odbiera sam</small>502 908 270';
    c.appendChild(a);
  });

  /* prawdziwa wysokość nagłówka (z paskiem makiety) dla przypiętej sceny */
  const hdr = document.querySelector('.mb-header');
  const mierz = () => { if (hdr) document.documentElement.style.setProperty('--hdr-h', hdr.offsetHeight + 'px'); };
  mierz(); addEventListener('resize', mierz);

  if (!hero) return;

  /* nagłówek: słowa w osobnych spanach; „0 zł” wyróżnione */
  const h1 = hero.querySelector('.mb-hero__tytul');
  const slowa = [];
  if (h1 && h1.children.length === 0) {
    const tekst = h1.textContent.trim();
    h1.textContent = '';
    tekst.split(/ +/).forEach((s, i, all) => {
      const sp = document.createElement('span');
      sp.className = 'mb-slowo' + (/^0[  ]?zł/.test(s) ? ' mb-zero' : '');
      sp.textContent = s; sp.style.setProperty('--i', i);
      h1.appendChild(sp); slowa.push(sp);
      if (i < all.length - 1) h1.appendChild(document.createTextNode(' '));
    });
  }
  const startTytul = () => {
    if (!ruchOk) { hero.classList.add('is-gotowe'); return; }
    slowa.forEach(s => { s.style.width = s.getBoundingClientRect().width + 'px'; });
    hero.classList.add('is-start');
    hero.offsetWidth;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      hero.classList.add('is-gra'); hero.classList.remove('is-start');
      setTimeout(() => {
        slowa.forEach(s => { s.style.width = ''; });
        hero.classList.remove('is-gra'); hero.classList.add('is-gotowe');
      }, 2200);
    }));
  };
  (document.fonts ? document.fonts.ready : Promise.resolve()).then(startTytul);

  /* film: na komputerze przewijanie przesuwa kadry, na telefonie gra raz, gdy jest na ekranie */
  const kadr = hero.querySelector('.mb-hero__kadr');
  const video = hero.querySelector('.mb-hero__film video');
  const kroki = [...hero.querySelectorAll('.mb-hero__kroki li')];
  if (!kadr || !video) return;
  video.muted = true; video.playsInline = true; video.removeAttribute('controls');
  const podp = document.createElement('p');
  podp.className = 'mb-hero__podpowiedz'; podp.setAttribute('aria-hidden', 'true');
  podp.textContent = 'Przewiń';
  kadr.appendChild(podp);

  const PROGI = [0, 0.34, 0.68];
  const pokazKrok = p => {
    let n = 0; PROGI.forEach((g, i) => { if (p >= g) n = i; });
    kroki.forEach((k, i) => k.classList.toggle('is-aktywny', i === n));
    kadr.style.setProperty('--p', p.toFixed(4));
  };
  pokazKrok(0);
  if (!ruchOk) { kroki.forEach(k => k.classList.add('is-aktywny')); return; }

  const scena = hero.querySelector('.mb-hero__scena');
  const przewijany = () => getComputedStyle(scena).position === 'sticky';
  let cel = 0, teraz = 0, petla = false;
  const czas = () => video.duration || 10;

  const krok = () => {
    teraz += (cel - teraz) * 0.18;
    if (Math.abs(cel - teraz) < 0.0015) teraz = cel;
    const t = teraz * (czas() - 0.05);
    if (Math.abs(video.currentTime - t) > 1 / 60 && !video.seeking) video.currentTime = t;
    pokazKrok(teraz);
    if (teraz !== cel) requestAnimationFrame(krok); else petla = false;
  };
  const naPrzewiniecie = () => {
    if (!przewijany()) return;
    const r = hero.getBoundingClientRect();
    const zakres = hero.offsetHeight - scena.offsetHeight;
    cel = Math.min(1, Math.max(0, -r.top / Math.max(1, zakres)));
    hero.classList.toggle('is-przewijane', cel > 0.02);
    if (!petla) { petla = true; requestAnimationFrame(krok); }
  };
  addEventListener('scroll', naPrzewiniecie, { passive: true });
  addEventListener('resize', naPrzewiniecie);
  video.addEventListener('loadedmetadata', naPrzewiniecie);
  naPrzewiniecie();

  /* telefon: zwykłe odtworzenie, napisy idą za czasem filmu */
  let zagrany = false;
  video.addEventListener('timeupdate', () => { if (!przewijany()) pokazKrok(video.currentTime / czas()); });
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(e => {
      if (przewijany()) return;
      if (e[0].isIntersecting && !zagrany) { zagrany = true; video.play().catch(() => {}); }
    }, { threshold: 0.55 }).observe(kadr);
  }
})();
