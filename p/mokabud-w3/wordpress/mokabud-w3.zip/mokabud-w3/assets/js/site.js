/* Mokabud — W3 „Plakat”: żuraw układa pasy „M” ze zdjęciem, kinetyczny nagłówek, menu. */
(() => {
  const ruchOk = !matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hero = document.querySelector('.mb-hero');
  const NS = 'http://www.w3.org/2000/svg';

  /* telefon na dole menu mobilnego */
  document.querySelectorAll('.mb-nav .wp-block-navigation__responsive-container-content').forEach(c => {
    const a = document.createElement('a');
    a.className = 'mb-menu-tel'; a.href = 'tel:+48502908270';
    a.innerHTML = '<small>Zadzwoń, Tobiasz odbiera sam</small>502 908 270';
    c.appendChild(a);
  });

  if (!hero) return;

  /* nagłówek: słowa w osobnych spanach; „0 zł” wyróżnione */
  const h1 = hero.querySelector('.mb-hero__tytul');
  const slowa = [];
  if (h1 && h1.children.length === 0) {
    const tekst = h1.textContent.trim();
    h1.textContent = '';
    tekst.split(/ +/).forEach((s, i, all) => {
      const sp = document.createElement('span');
      sp.className = 'mb-slowo' + (/^0[  ]?zł/.test(s) ? ' mb-zero' : '');
      sp.textContent = s; sp.style.setProperty('--i', i);
      h1.appendChild(sp); slowa.push(sp);
      if (i < all.length - 1) h1.appendChild(document.createTextNode(' '));
    });
  }

  /* zdjęcie → trzy pasy z pochylonego „M”, czerwone tło i żuraw nad nimi */
  const fig = hero.querySelector('.mb-hero__foto');
  if (!fig) return;
  const img = fig.querySelector('img');
  const tlo = document.createElement('div'); tlo.className = 'mb-hero__tlo'; fig.appendChild(tlo);
  const GORA = [[.16, .40], [.45, .71], [.76, 1]]; /* górne krawędzie pasów (ułamek szerokości) */
  const pasy = GORA.map((g, n) => {
    const p = document.createElement('div');
    p.className = 'mb-pas mb-pas--' + (n + 1); p.setAttribute('aria-hidden', 'true');
    const k = img.cloneNode(); k.removeAttribute('class'); k.removeAttribute('srcset'); k.removeAttribute('sizes');
    k.src = img.currentSrc || img.src; k.alt = ''; k.loading = 'eager';
    p.appendChild(k); fig.appendChild(p); return p;
  });
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', 'mb-zuraw'); svg.setAttribute('aria-hidden', 'true');
  fig.appendChild(svg);

  const el = (tag, at, rodzic) => {
    const e = document.createElementNS(NS, tag);
    for (const k in at) e.setAttribute(k, at[k]);
    (rodzic || svg).appendChild(e); return e;
  };
  const r1 = v => Math.round(v * 10) / 10;

  /* geometria liczona w pikselach przy każdej zmianie rozmiaru */
  let G = null, dyn = null;
  const kratownica = (x1, x2, yt, yb, g) => {
    let d = `M${r1(x1)} ${r1(yt)}H${r1(x2)}M${r1(x1)} ${r1(yb)}H${r1(x2)}`;
    const krok = (yb - yt) * 1.15, dir = x2 > x1 ? 1 : -1;
    let x = x1, gora = false;
    d += `M${r1(x)} ${r1(yb)}`;
    while ((x2 - x) * dir > 0.5) {
      x = dir > 0 ? Math.min(x + krok, x2) : Math.max(x - krok, x2);
      d += `L${r1(x)} ${r1(gora ? yb : yt)}`; gora = !gora;
    }
    el('path', { d, class: 'k' }, g);
  };
  const buduj = () => {
    const zx = parseFloat(getComputedStyle(svg).getPropertyValue('--zx')) || 0;
    const W = fig.clientWidth + zx, H = fig.clientHeight;
    const zh = pasy[0].offsetTop, FW = fig.clientWidth, SH = H - zh;
    const tel = zx === 0;
    const mX = tel ? 26 : zx - 40, mw = tel ? 12 : 16;
    const jt = zh * 0.25, jh = Math.max(10, Math.min(18, zh * 0.16)), jb = jt + jh;
    svg.setAttribute('viewBox', `0 0 ${r1(W)} ${r1(H)}`);
    svg.textContent = '';
    const st = el('g', {});
    /* maszt */
    const mL = mX - mw / 2, mR = mX + mw / 2;
    let d = `M${r1(mL)} ${r1(jb)}V${r1(H)}M${r1(mR)} ${r1(jb)}V${r1(H)}`;
    for (let y = jb, s = 0; y < H; y += mw * 1.1, s++) d += `M${r1(s % 2 ? mR : mL)} ${r1(y)}L${r1(s % 2 ? mL : mR)} ${r1(Math.min(H, y + mw * 1.1))}`;
    el('path', { d, class: 'k' }, st);
    /* wierzchołek i odciągi */
    const top = Math.max(3, jt - zh * 0.3);
    const wysiegnik = W - 8, przeciw = mX - (tel ? 70 : 96);
    el('path', { d: `M${r1(mL)} ${r1(jt)}L${r1(mX)} ${r1(top)}L${r1(mR)} ${r1(jt)}M${r1(mX)} ${r1(top)}L${r1(mX + (wysiegnik - mX) * 0.62)} ${r1(jt)}M${r1(mX)} ${r1(top)}L${r1(przeciw + 6)} ${r1(jt)}`, class: 'k2' }, st);
    /* wysięgnik i przeciwwysięgnik */
    kratownica(mR, wysiegnik, jt, jb, st);
    kratownica(mL, przeciw, jt, jb, st);
    el('rect', { x: r1(przeciw), y: r1(jb), width: tel ? 18 : 26, height: r1(jh * 1.7), class: 'czer' }, st);
    /* kabina operatora */
    el('rect', { x: r1(mR), y: r1(jb), width: tel ? 14 : 20, height: tel ? 11 : 16, class: 'pel' }, st);
    el('rect', { x: r1(mR + 3), y: r1(jb + 3), width: tel ? 8 : 12, height: tel ? 4 : 6, class: 'okno' }, st);
    /* tablica z nazwą firmy na wysięgniku */
    const tx0 = mR + (tel ? 30 : 46), tw = tel ? 72 : 104;
    el('rect', { x: r1(tx0), y: r1(jt), width: tw, height: r1(jh), class: 'pel' }, st);
    const t = el('text', { x: r1(tx0 + tw / 2), y: r1(jt + jh / 2 + jh * 0.24), 'text-anchor': 'middle', style: `font-size:${r1(jh * 0.62)}px` }, st);
    t.textContent = 'MOKABUD';
    /* części ruchome */
    dyn = {
      lina: el('path', { d: '', class: 'lina', fill: 'none' }),
      wozek: el('rect', { width: tel ? 12 : 16, height: 5, class: 'pel' }),
      hak: el('rect', { width: 10, height: 6, class: 'pel' }),
      hakJ: el('path', { d: '', class: 'k' }),
    };
    const sloty = GORA.map(g => zx + (g[0] + g[1]) / 2 * FW);
    G = { zx, W, H, zh, FW, SH, jb, mX, sloty, k: Math.max(8, Math.min(zh - jb - 32, SH * 0.12)), park: sloty[2], tel };
  };

  /* oś czasu: każdy pas pojawia się na haku, kołysze się i osiada; wózek jedzie do następnego */
  const S = [0.1, 0.95, 1.8], OPUSZCZ = 0.55, KONIEC = 2.6;
  const ease = x => x < 0 ? 0 : x > 1 ? 1 : 1 - Math.pow(1 - x, 3);
  const inout = x => x < 0 ? 0 : x > 1 ? 1 : x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
  let scrollP = 0;
  const rysuj = t => {
    if (!G) return;
    const { zx, FW, zh, jb, sloty, k } = G;
    let wx = sloty[0], hakY = jb + 18, aktywny = -1, sway = 0, top = 0;
    pasy.forEach((p, i) => {
      const tau = t - S[i];
      if (tau < 0) { p.style.opacity = 0; p.style.transform = `translate3d(0,${-k}px,0)`; return; }
      const op = Math.min(1, tau / 0.18);
      const zjazd = inout((tau - 0.12) / OPUSZCZ);
      const sw = tau < 0.12 + OPUSZCZ + 0.25 ? 7 * Math.sin(tau * 11) * Math.exp(-tau * 4.5) : 0;
      const dy = -k * (1 - zjazd);
      p.style.opacity = op;
      p.style.transform = `translate3d(${r1(sw)}px,${r1(dy)}px,0)`;
      if (tau < 0.12 + OPUSZCZ) { aktywny = i; sway = sw; top = zh + dy; }
    });
    /* wózek i hak */
    if (aktywny >= 0) {
      wx = sloty[aktywny]; hakY = top - 24;
    } else {
      /* po odłożeniu pasa: hak wraca w górę, wózek jedzie do kolejnego miejsca */
      let i = 0; while (i < 2 && t > S[i + 1]) i++;
      const zwolnienie = S[i] + 0.12 + OPUSZCZ;
      const q = inout((t - zwolnienie) / Math.max(0.01, (i < 2 ? S[i + 1] : zwolnienie + 0.3) - zwolnienie));
      const cel = i < 2 ? sloty[i + 1] : G.park;
      wx = sloty[i] + (cel - sloty[i]) * q;
      const dol = zh - 24, gora = i < 2 ? zh - k - 24 : jb + 18;
      hakY = dol + (gora - dol) * q;
      if (t < S[0]) { wx = sloty[0]; hakY = zh - k - 24; }
    }
    /* po animacji przewijanie przesuwa wózek wzdłuż wysięgnika */
    if (t >= KONIEC && scrollP > 0 && !G.tel) {
      wx = G.park + (G.mX + 60 - G.park) * scrollP;
      hakY = jb + 18 + scrollP * (G.H - jb) * 0.45;
    }
    const hx = wx + sway;
    const { lina, wozek, hak, hakJ } = dyn;
    wozek.setAttribute('x', r1(wx - (G.tel ? 6 : 8))); wozek.setAttribute('y', r1(jb));
    let d = `M${r1(wx - 2)} ${r1(jb + 5)}L${r1(hx - 2)} ${r1(hakY)}M${r1(wx + 2)} ${r1(jb + 5)}L${r1(hx + 2)} ${r1(hakY)}`;
    if (aktywny >= 0) {
      const g = GORA[aktywny];
      d += `M${r1(hx)} ${r1(hakY + 8)}L${r1(zx + g[0] * FW + sway + 4)} ${r1(top)}M${r1(hx)} ${r1(hakY + 8)}L${r1(zx + g[1] * FW + sway - 4)} ${r1(top)}`;
    }
    lina.setAttribute('d', d);
    hak.setAttribute('x', r1(hx - 5)); hak.setAttribute('y', r1(hakY));
    hakJ.setAttribute('d', `M${r1(hx)} ${r1(hakY + 6)}v4a3.2 3.2 0 1 1 -3.6 3.1`);
  };

  let t0 = null, czas = ruchOk ? 0 : KONIEC, gotowe = !ruchOk;
  const petla = now => {
    if (t0 === null) t0 = now;
    czas = (now - t0) / 1000;
    rysuj(czas);
    if (czas < KONIEC) requestAnimationFrame(petla);
    else { gotowe = true; rysuj(KONIEC); }
  };

  const start = () => {
    buduj();
    hero.classList.add('mb-tlo-on');
    if (!ruchOk) { hero.classList.add('is-gotowe'); rysuj(KONIEC); return; }
    rysuj(0);
    /* stałe miejsce dla każdego słowa: litery rozciągają się w nim bez przeskoków wierszy */
    slowa.forEach(s => { s.style.width = s.getBoundingClientRect().width + 'px'; });
    hero.classList.add('is-start');
    hero.offsetWidth;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      hero.classList.add('is-gra');
      hero.classList.remove('is-start');
      /* żuraw rusza, gdy zdjęcie jest na ekranie (na telefonie jest pod przyciskami) */
      const r = fig.getBoundingClientRect();
      if (r.top < innerHeight * 0.45 || !('IntersectionObserver' in window)) requestAnimationFrame(petla);
      else {
        const io = new IntersectionObserver(e => {
          if (e[0].isIntersecting) { io.disconnect(); requestAnimationFrame(petla); }
        }, { threshold: 0.6 });
        io.observe(fig);
      }
      setTimeout(() => {
        slowa.forEach(s => { s.style.width = ''; });
        hero.classList.remove('is-gra');
        hero.classList.add('is-gotowe');
      }, 2200);
    }));
  };
  const czekaj = img.complete ? Promise.resolve() : new Promise(r => { img.addEventListener('load', r, { once: true }); img.addEventListener('error', r, { once: true }); });
  Promise.all([document.fonts ? document.fonts.ready : null, czekaj]).then(start);

  let rt;
  addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { buduj(); rysuj(gotowe ? KONIEC : czas); }, 120); });
  if (ruchOk) {
    let tik = false;
    addEventListener('scroll', () => {
      if (tik || !gotowe) return; tik = true;
      requestAnimationFrame(() => {
        tik = false;
        const r = hero.getBoundingClientRect();
        scrollP = Math.min(1, Math.max(0, -r.top / (r.height * 0.8)));
        rysuj(KONIEC);
      });
    }, { passive: true });
  }
})();
