/* Mokabud — W3 „Plakat”: hero z pasami „M”, kinetyczny nagłówek, menu. */
(() => {
  const ruchOk = !matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hero = document.querySelector('.mb-hero');

  /* telefon na dole menu mobilnego */
  document.querySelectorAll('.mb-nav .wp-block-navigation__responsive-container-content').forEach(c => {
    const a = document.createElement('a');
    a.className = 'mb-menu-tel'; a.href = 'tel:+48502908270';
    a.innerHTML = '<small>Zadzwoń, Tobiasz odbiera sam</small>502 908 270';
    c.appendChild(a);
  });

  if (!hero) return;

  /* nagłówek: słowa w osobnych spanach; „0 zł” na biało */
  const h1 = hero.querySelector('.mb-hero__tytul');
  const slowa = [];
  if (h1 && h1.children.length === 0) {
    const tekst = h1.textContent.trim();
    h1.textContent = '';
    tekst.split(/ +/).forEach((s, i, all) => {
      const sp = document.createElement('span');
      sp.className = 'mb-slowo' + (/^0 ?zł/.test(s) || /^0 zł/.test(s) ? ' mb-zero' : '');
      sp.textContent = s; sp.style.setProperty('--i', i);
      h1.appendChild(sp); slowa.push(sp);
      if (i < all.length - 1) h1.appendChild(document.createTextNode(' '));
    });
  }

  /* zdjęcie → trzy pasy z pochylonego „M” */
  const fig = hero.querySelector('.mb-hero__foto');
  const pasy = [];
  if (fig) {
    const img = fig.querySelector('img');
    [1, 2, 3].forEach(n => {
      const p = document.createElement('div');
      p.className = 'mb-pas mb-pas--' + n; p.setAttribute('aria-hidden', 'true');
      const k = img.cloneNode(); k.removeAttribute('class'); k.alt = ''; k.loading = 'eager';
      p.appendChild(k); fig.appendChild(p); pasy.push(p);
    });
  }

  const start = () => {
    if (!ruchOk) { hero.classList.add('is-gotowe'); return; }
    /* stałe miejsce dla każdego słowa: litery rozciągają się w nim bez przeskoków wierszy */
    slowa.forEach(s => { s.style.width = s.getBoundingClientRect().width + 'px'; });
    hero.classList.add('is-start');
    hero.offsetWidth;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      hero.classList.add('is-gra');
      hero.classList.remove('is-start');
      setTimeout(() => {
        slowa.forEach(s => { s.style.width = ''; });
        hero.classList.remove('is-gra');
        hero.classList.add('is-gotowe');
      }, 2200);
    }));
  };
  (document.fonts ? document.fonts.ready : Promise.resolve()).then(start);

  /* przewijanie i kursor: pasy rozjeżdżają się w różnym tempie */
  if (!ruchOk || !pasy.length) return;
  let mx = 0, my = 0, tik = false;
  const rysuj = () => {
    tik = false;
    if (!hero.classList.contains('is-gotowe')) return;
    const r = hero.getBoundingClientRect();
    const p = Math.min(1, Math.max(0, -r.top / r.height));
    const sila = [0.18, 0.32, 0.5];
    pasy.forEach((el, i) => {
      el.style.transform = `translate3d(${mx * (i + 1) * 4}px, ${-p * r.height * sila[i] + my * (i + 1) * 3}px, 0)`;
    });
  };
  const zlec = () => { if (!tik) { tik = true; requestAnimationFrame(rysuj); } };
  addEventListener('scroll', zlec, { passive: true });
  if (matchMedia('(pointer: fine)').matches) {
    hero.addEventListener('pointermove', e => {
      const r = hero.getBoundingClientRect();
      mx = (e.clientX - r.left) / r.width - .5; my = (e.clientY - r.top) / r.height - .5; zlec();
    });
    hero.addEventListener('pointerleave', () => { mx = my = 0; zlec(); });
  }
  setTimeout(zlec, 2300);
})();
