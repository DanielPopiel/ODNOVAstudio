<?php
/**
 * Formularz wyceny: [mokabud_formularz]
 * Wiadomość idzie na adres z Ustawienia → Ogólne (adres administratora)
 * albo na adres podany w atrybucie: [mokabud_formularz do="biuro@mokabud.pl"]
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_shortcode( 'mokabud_formularz', function ( $atts ) {
	$atts = shortcode_atts( array( 'do' => '' ), $atts );
	$ok   = isset( $_GET['wyslano'] ) ? '<p class="mb-form__ok" role="status">Dziękujemy — oddzwonimy w ciągu jednego dnia roboczego.</p>' : '';
	ob_start(); ?>
	<form class="mb-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php echo $ok; ?>
		<input type="hidden" name="action" value="mokabud_wycena">
		<input type="hidden" name="do" value="<?php echo esc_attr( $atts['do'] ); ?>">
		<?php wp_nonce_field( 'mokabud_wycena', 'mb_nonce' ); ?>
		<p class="mb-form__row"><label for="mb-imie">Imię i nazwisko</label><input id="mb-imie" name="imie" autocomplete="name" required></p>
		<p class="mb-form__row"><label for="mb-tel">Telefon</label><input id="mb-tel" name="tel" type="tel" autocomplete="tel" inputmode="tel" required></p>
		<p class="mb-form__row"><label for="mb-gdzie">Gdzie jest działka? <span class="opc">(opcjonalnie)</span></label><input id="mb-gdzie" name="gdzie" placeholder="np. Andrzejów, gm. Andrespol"></p>
		<p class="mb-form__row"><label for="mb-zakres">Zakres</label>
			<select id="mb-zakres" name="zakres">
				<option value="" selected>Wybierz zakres…</option>
				<option>Stan surowy otwarty</option>
				<option>Stan surowy zamknięty</option>
				<option>Stan deweloperski</option>
				<option>Dom pod klucz</option>
				<option>Pojedynczy etap lub usługa</option>
				<option>Jeszcze nie wiem</option>
			</select></p>
		<p class="mb-form__row mb-form__row--full"><label for="mb-opis">Co już Państwo mają? <span class="opc">(opcjonalnie)</span></label><textarea id="mb-opis" name="opis" rows="4" placeholder="Projekt, pozwolenie, termin rozpoczęcia — co wiadomo na dziś"></textarea></p>
		<p class="mb-form__row mb-form__row--full mb-form__zgoda"><label><input type="checkbox" name="zgoda" required> <span>Zgadzam się na kontakt w sprawie wyceny. Administratorem danych jest Mokabud Tobiasz Mosieniak, szczegóły w <a href="/polityka-prywatnosci/">polityce prywatności</a>.</span></label></p>
		<p class="mb-form__row mb-form__row--full"><button type="submit" class="mb-btn mb-btn--solid">Wyślij zapytanie</button></p>
		<p class="mb-form__row mb-form__row--full mb-form__obietnica">Oddzwonimy i umówimy oględziny działki.</p>
	</form>
	<?php
	return ob_get_clean();
} );

function mokabud_obsluz_wycene() {
	if ( ! isset( $_POST['mb_nonce'] ) || ! wp_verify_nonce( $_POST['mb_nonce'], 'mokabud_wycena' ) ) {
		wp_die( 'Formularz wygasł — proszę odświeżyć stronę.' );
	}
	$do    = sanitize_email( wp_unslash( $_POST['do'] ?? '' ) );
	$do    = $do ? $do : get_option( 'admin_email' );
	$pola  = array( 'imie' => 'Imię i nazwisko', 'tel' => 'Telefon', 'gdzie' => 'Działka', 'zakres' => 'Zakres', 'opis' => 'Opis' );
	$tresc = '';
	foreach ( $pola as $k => $nazwa ) {
		$tresc .= $nazwa . ': ' . sanitize_textarea_field( wp_unslash( $_POST[ $k ] ?? '' ) ) . "\n";
	}
	wp_mail( $do, 'Zapytanie o wycenę ze strony', $tresc );
	wp_safe_redirect( add_query_arg( 'wyslano', '1', wp_get_referer() ? wp_get_referer() : home_url( '/' ) ) . '#kontakt' );
	exit;
}
add_action( 'admin_post_nopriv_mokabud_wycena', 'mokabud_obsluz_wycene' );
add_action( 'admin_post_mokabud_wycena', 'mokabud_obsluz_wycene' );
