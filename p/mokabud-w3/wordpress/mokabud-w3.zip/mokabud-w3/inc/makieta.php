<?php
/**
 * Tryb makiety: oznacza bloki, które klient zmienia sam (data-edytuj).
 * Włączany tylko przy eksporcie makiety (opcja mokabud_makieta = 1).
 * Na prawdziwej stronie nic nie robi.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_filter( 'render_block', function ( $html, $block ) {
	if ( ! get_option( 'mokabud_makieta' ) || is_admin() || '' === trim( $html ) ) {
		return $html;
	}
	$mapa = array(
		'core/heading'   => 'tekst',
		'core/paragraph' => 'tekst',
		'core/list'      => 'lista',
		'core/table'     => 'tabela',
		'core/button'    => 'przycisk',
		'core/image'     => 'zdjęcie',
		'core/cover'     => 'zdjęcie',
		'core/query'     => 'lista z panelu',
	);
	$nazwa = $block['blockName'] ?? '';
	if ( ! isset( $mapa[ $nazwa ] ) ) {
		return $html;
	}
	$etykieta = $mapa[ $nazwa ];
	if ( 'core/query' === $nazwa ) {
		$typ = $block['attrs']['query']['postType'] ?? 'post';
		$etykieta = array( 'realizacja' => 'Realizacje → Dodaj', 'opinia' => 'Opinie → Dodaj', 'post' => 'Wpisy → Dodaj' )[ $typ ] ?? 'lista z panelu';
	}
	$p = new WP_HTML_Tag_Processor( $html );
	if ( $p->next_tag() ) {
		$p->set_attribute( 'data-edytuj', $etykieta );
	}
	return $p->get_updated_html();
}, 20, 2 );

/* Skrót do edycji strony głównej: /?mokabud=edytuj (dla zalogowanych) */
add_action( 'template_redirect', function () {
	if ( isset( $_GET['mokabud'] ) && 'edytuj' === $_GET['mokabud'] && current_user_can( 'edit_pages' ) ) {
		$id = (int) get_option( 'page_on_front' );
		if ( $id ) { wp_safe_redirect( admin_url( 'post.php?post=' . $id . '&action=edit' ) ); exit; }
	}
} );
