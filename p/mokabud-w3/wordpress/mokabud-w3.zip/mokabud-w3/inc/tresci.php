<?php
/**
 * Realizacje i opinie jako osobne listy w panelu.
 * Nowa budowa = „Realizacje → Dodaj nową”: tytuł, zdjęcie wyróżniające,
 * krótki opis i zaznaczony zakres. Strona główna sama ją pokaże.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', function () {
	register_post_type( 'realizacja', array(
		'labels'        => array(
			'name'          => 'Realizacje',
			'singular_name' => 'Realizacja',
			'add_new'       => 'Dodaj realizację',
			'add_new_item'  => 'Nowa realizacja',
			'edit_item'     => 'Edytuj realizację',
			'all_items'     => 'Wszystkie realizacje',
			'menu_name'     => 'Realizacje',
		),
		'public'        => true,
		'show_in_rest'  => true,
		'has_archive'   => 'realizacje',
		'rewrite'       => array( 'slug' => 'realizacje' ),
		'menu_icon'     => 'dashicons-admin-home',
		'menu_position' => 5,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
	) );

	register_taxonomy( 'zakres', array( 'realizacja' ), array(
		'labels'            => array( 'name' => 'Zakres prac', 'singular_name' => 'Zakres', 'add_new_item' => 'Dodaj zakres' ),
		'public'            => true,
		'hierarchical'      => true,
		'show_in_rest'      => true,
		'show_admin_column' => true,
		'rewrite'           => array( 'slug' => 'zakres' ),
	) );

	register_taxonomy( 'miejscowosc', array( 'realizacja' ), array(
		'labels'            => array( 'name' => 'Miejscowość', 'singular_name' => 'Miejscowość', 'add_new_item' => 'Dodaj miejscowość' ),
		'public'            => true,
		'hierarchical'      => true,
		'show_in_rest'      => true,
		'show_admin_column' => true,
		'rewrite'           => array( 'slug' => 'budowa' ),
	) );

	register_post_type( 'opinia', array(
		'labels'        => array(
			'name'          => 'Opinie',
			'singular_name' => 'Opinia',
			'add_new'       => 'Dodaj opinię',
			'add_new_item'  => 'Nowa opinia',
			'edit_item'     => 'Edytuj opinię',
		),
		'public'              => true,
		'publicly_queryable'  => true,
		'exclude_from_search' => true,
		'has_archive'         => false,
		'rewrite'             => false,
		'show_ui'             => true,
		'show_in_rest'  => true,
		'menu_icon'     => 'dashicons-format-quote',
		'menu_position' => 6,
		'supports'      => array( 'title', 'editor', 'excerpt' ),
	) );
} );

/* Podpowiedź w polu tytułu */
add_filter( 'enter_title_here', function ( $t, $post ) {
	if ( 'realizacja' === $post->post_type ) { return 'Np. Dom w Andrzejowie pod Łodzią'; }
	if ( 'opinia' === $post->post_type ) { return 'Podpis autora, np. A.I., Andrzejów'; }
	return $t;
}, 10, 2 );
