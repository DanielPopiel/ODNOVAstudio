<?php
/**
 * Treści startowe. Realizacje i opinie wzięte z opinii klientów Mokabud na Oferteo;
 * zdjęcia poglądowe do podmiany na zdjęcia z budów.
 */
return array(
	'obrazy' => array(
		'etap1'  => array( '01-dzialka.jpg', 'Działka przygotowana pod budowę domu' ),
		'etap2'  => array( '02-plyta.jpg', 'Płyta fundamentowa z wyprowadzonymi prętami zbrojenia' ),
		'etap3'  => array( '03-mury.jpg', 'Mury z bloczków ceramicznych i szalunek stropu' ),
		'etap4'  => array( '04-sso.jpg', 'Stan surowy otwarty z więźbą dachową' ),
		'etap5'  => array( '05-dom.jpg', 'Gotowy dom jednorodzinny pod Łodzią' ),
		'real1'  => array( 'r1-andrzejow.jpg', 'Dom z betonowymi ramami okien, Andrzejów' ),
		'real2'  => array( 'r2-lutomiersk.jpg', 'Dom z antresolą i attyką, okolice Lutomierska' ),
		'real3'  => array( 'r3-strop.jpg', 'Strop betonowy i schody, budowa pod Łodzią' ),
	),
	'zakresy' => array( 'Stan surowy otwarty', 'Stan surowy zamknięty', 'Stan deweloperski', 'Pod klucz', 'Elewacja', 'Garaż i ogrodzenie' ),
	'realizacje' => array(
		array(
			'tytul'   => 'Dom z dużymi przeszkleniami w Andrzejowie',
			'miejsce' => 'Andrzejów',
			'zakres'  => array( 'Stan surowy otwarty', 'Elewacja', 'Garaż i ogrodzenie' ),
			'data'    => '2026-02-20 10:00:00',
			'zdjecie' => 'real1',
			'krotko'  => 'Płyta fundamentowa, ściany nośne i działowe z Porothermu, strop betonowy, schody i betonowe ramy frontowych okien. Później elewacja, garaż i ogrodzenie.',
			'tresc'   => '<!-- wp:paragraph --><p>Płyta fundamentowa, ściany nośne i działowe z bloczków Porotherm, strop betonowy, schody oraz duże betonowe konstrukcje frontowych okien. Po stanie surowym ta sama ekipa wykonała elewację, postawiła garaż i ogrodzenie.</p><!-- /wp:paragraph -->',
		),
		array(
			'tytul'   => 'Dom z piwnicą i antresolą koło Lutomierska',
			'miejsce' => 'Lutomiersk',
			'zakres'  => array( 'Stan surowy otwarty' ),
			'data'    => '2026-03-15 10:00:00',
			'zdjecie' => 'real2',
			'krotko'  => 'Płyta pod piwnicą i ławy, mury betonowe, strop monolityczny z antresolą, attyki i strop Teriva. Generalne wykonawstwo do stanu surowego otwartego.',
			'tresc'   => '<!-- wp:paragraph --><p>Generalne wykonawstwo do stanu surowego otwartego: płyta pod piwnicą i ławy fundamentowe, mury betonowe, strop monolityczny z antresolą, ściany, attyki i strop Teriva. Rozliczenie po każdym zamkniętym etapie, bez zaliczek.</p><!-- /wp:paragraph -->',
		),
		array(
			'tytul'   => 'Dom parterowy z poddaszem pod Łodzią',
			'miejsce' => 'Okolice Łodzi',
			'zakres'  => array( 'Stan surowy otwarty' ),
			'data'    => '2025-11-05 10:00:00',
			'zdjecie' => 'real3',
			'krotko'  => 'Od pierwszej łopaty po dach: fundamenty, mury, działówki, strop betonowy i schody betonowe. Dostawy i sprzątanie po stronie Mokabud.',
			'tresc'   => '<!-- wp:paragraph --><p>Fundamenty, mury zewnętrzne i działowe, strop betonowy, schody betonowe. Mokabud prowadził też dostawy materiałów i poprawił błędy w projekcie wychwycone na budowie.</p><!-- /wp:paragraph -->',
		),
	),
	'opinie' => array(
		array( 'kto' => 'O.Z., dom koło Lutomierska', 'data' => '2026-04-01 10:00:00', 'tekst' => 'Pełny wgląd w koszty i zero zaliczek. Rozliczaliśmy się dopiero po zamkniętym etapie. Ekipa jest stała, znają się na robocie i nie ma u nich rotacji.' ),
		array( 'kto' => 'A.I., Andrzejów pod Łodzią', 'data' => '2026-03-01 10:00:00', 'tekst' => 'Zajęcie się każdym chyba elementem budowy, od dostaw po dogranie innych ekip, które po nich działały. Kierownik zadowolony z profesjonalizmu, na budowie porządek.' ),
		array( 'kto' => 'A.S., dom pod Łodzią', 'data' => '2025-11-01 10:00:00', 'tekst' => 'Uczciwe podejście do finansów, terminowa realizacja, świetna jakość robót. Firma ogarnęła wszystko: dostawy, budowę, sprzątanie i nawet błędy projektowe.' ),
		array( 'kto' => 'W., pierwszy dom', 'data' => '2024-10-01 10:00:00', 'tekst' => 'Otrzymaliśmy budowę posprzątaną, pograbioną i gotową dla następnych ekip. Polecam zwłaszcza, jeśli to pierwszy dom i człowiek jest zielony.' ),
	),
	'porady' => array(
		array(
			'tytul'   => 'Płyta fundamentowa czy ławy: od czego zależy wybór',
			'data'    => '2026-05-12 10:00:00',
			'zdjecie' => 'etap2',
			'krotko'  => 'Grunt, poziom wód, piwnica i budżet. Tłumaczymy, kiedy płyta oszczędza czas, a kiedy lepiej zostać przy ławach.',
			'tresc'   => '<!-- wp:paragraph --><p>Treść porady do uzupełnienia przez firmę.</p><!-- /wp:paragraph -->',
		),
		array(
			'tytul'   => 'Co dokładnie dostajesz w stanie surowym zamkniętym',
			'data'    => '2026-04-08 10:00:00',
			'zdjecie' => 'etap4',
			'krotko'  => 'Okna, drzwi zewnętrzne, pokrycie dachu. I czego w tym etapie jeszcze nie ma, żeby nie było niespodzianek przy odbiorze.',
			'tresc'   => '<!-- wp:paragraph --><p>Treść porady do uzupełnienia przez firmę.</p><!-- /wp:paragraph -->',
		),
		array(
			'tytul'   => 'Jak rozliczać budowę etapami, żeby nie płacić z góry',
			'data'    => '2026-03-03 10:00:00',
			'zdjecie' => 'etap3',
			'krotko'  => 'Harmonogram płatności powiązany z odbiorami. Jak go zapisać w umowie i co sprawdza kierownik budowy przed każdą fakturą.',
			'tresc'   => '<!-- wp:paragraph --><p>Treść porady do uzupełnienia przez firmę.</p><!-- /wp:paragraph -->',
		),
	),
);
