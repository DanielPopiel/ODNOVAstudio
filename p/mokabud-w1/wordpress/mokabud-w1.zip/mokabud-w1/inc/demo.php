<?php
/**
 * Wgrywa treści startowe: zdjęcia do biblioteki mediów, realizacje, opinie,
 * porady i stronę główną. Uruchamiane raz (demo w przeglądarce / pierwsze wdrożenie).
 * Potem wszystko jest zwykłą treścią do edycji w panelu.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

function mokabud_demo_obraz( $plik, $tytul ) {
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$src = get_template_directory() . '/assets/demo/' . $plik;
	if ( ! file_exists( $src ) ) { return 0; }
	$up  = wp_upload_dir();
	$dst = trailingslashit( $up['path'] ) . $plik;
	copy( $src, $dst );
	$id = wp_insert_attachment( array(
		'post_mime_type' => wp_check_filetype( $plik )['type'],
		'post_title'     => $tytul,
		'post_status'    => 'inherit',
	), $dst );
	update_post_meta( $id, '_wp_attachment_image_alt', $tytul );
	wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $dst ) );
	return $id;
}

function mokabud_demo_setup() {
	if ( get_option( 'mokabud_demo_done' ) ) { return 'juz'; }
	$dane = require get_template_directory() . '/content/dane.php';
	kses_remove_filters();

	update_option( 'blogname', 'Mokabud' );
	update_option( 'blogdescription', 'Budowa domów — Łódź i okolice' );
	update_option( 'permalink_structure', '/%postname%/' );

	/* zdjęcia */
	$img = array();
	foreach ( $dane['obrazy'] as $klucz => $o ) {
		$img[ $klucz ] = mokabud_demo_obraz( $o[0], $o[1] );
	}

	$logo = mokabud_demo_obraz( 'logo.png', 'Mokabud — logo' );
	if ( $logo ) { set_theme_mod( 'custom_logo', $logo ); update_option( 'site_logo', $logo ); }
	$ikona = mokabud_demo_obraz( 'ikona.png', 'Mokabud — ikona strony' );
	if ( $ikona ) { update_option( 'site_icon', $ikona ); }

	/* zakresy */
	foreach ( $dane['zakresy'] as $z ) {
		if ( ! term_exists( $z, 'zakres' ) ) { wp_insert_term( $z, 'zakres' ); }
	}

	/* realizacje */
	foreach ( $dane['realizacje'] as $r ) {
		$id = wp_insert_post( array(
			'post_type'    => 'realizacja',
			'post_status'  => 'publish',
			'post_title'   => $r['tytul'],
			'post_excerpt' => $r['krotko'],
			'post_content' => $r['tresc'],
			'post_date'    => $r['data'],
		) );
		wp_set_object_terms( $id, $r['zakres'], 'zakres' );
		wp_set_object_terms( $id, $r['miejsce'], 'miejscowosc' );
		if ( ! empty( $img[ $r['zdjecie'] ] ) ) { set_post_thumbnail( $id, $img[ $r['zdjecie'] ] ); }
	}

	/* opinie */
	foreach ( $dane['opinie'] as $o ) {
		wp_insert_post( array(
			'post_type'    => 'opinia',
			'post_status'  => 'publish',
			'post_title'   => $o['kto'],
			'post_content' => '<!-- wp:paragraph --><p>' . esc_html( $o['tekst'] ) . '</p><!-- /wp:paragraph -->',
			'post_excerpt' => $o['tekst'],
			'post_date'    => $o['data'],
		) );
	}

	/* porady */
	foreach ( $dane['porady'] as $p ) {
		$id = wp_insert_post( array(
			'post_type'    => 'post',
			'post_status'  => 'publish',
			'post_title'   => $p['tytul'],
			'post_excerpt' => $p['krotko'],
			'post_content' => $p['tresc'],
			'post_date'    => $p['data'],
		) );
		if ( ! empty( $p['zdjecie'] ) && ! empty( $img[ $p['zdjecie'] ] ) ) { set_post_thumbnail( $id, $img[ $p['zdjecie'] ] ); }
	}
	foreach ( array( 'witaj-swiecie', 'hello-world' ) as $slug ) {
		foreach ( get_posts( array( 'name' => $slug, 'post_type' => 'post', 'numberposts' => 1 ) ) as $p ) { wp_delete_post( $p->ID, true ); }
	}
	foreach ( array( 'przykladowa-strona', 'sample-page' ) as $slug ) {
		foreach ( get_posts( array( 'name' => $slug, 'post_type' => 'page', 'numberposts' => 1 ) ) as $p ) { wp_delete_post( $p->ID, true ); }
	}

	/* strona główna */
	$html = file_get_contents( get_template_directory() . '/content/home.html' );
	$html = preg_replace_callback( '/\{\{(img|id):([a-z0-9-]+)\}\}/', function ( $m ) use ( $img ) {
		$id = $img[ $m[2] ] ?? 0;
		return 'img' === $m[1] ? wp_get_attachment_image_url( $id, 'full' ) : (string) $id;
	}, $html );
	$home = wp_insert_post( array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_title'   => 'Strona główna',
		'post_name'    => 'strona-glowna',
		'post_content' => $html,
	) );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home );

	$blog = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Porady', 'post_name' => 'porady' ) );
	update_option( 'page_for_posts', $blog );

	/* edytor bez okna powitalnego */
	global $wpdb;
	foreach ( get_users( array( 'role' => 'administrator', 'fields' => 'ID' ) ) as $uid ) {
		update_user_meta( $uid, $wpdb->get_blog_prefix() . 'persisted_preferences', array(
			'core/edit-post' => array( 'welcomeGuide' => false, 'welcomeGuideTemplate' => false ),
			'core'           => array( 'enableChoosePatternModal' => false, 'welcomeGuide' => false ),
			'_modified'      => gmdate( 'c' ),
		) );
	}

	flush_rewrite_rules();
	update_option( 'mokabud_demo_done', 1 );
	return $home;
}

/* Przy pracy nad makietą: ponownie wgrywa content/home.html do strony głównej. */
function mokabud_demo_odswiez_strone() {
	kses_remove_filters();
	$img = array();
	$dane = require get_template_directory() . '/content/dane.php';
	foreach ( $dane['obrazy'] as $klucz => $o ) {
		$a = get_posts( array( 'post_type' => 'attachment', 'title' => $o[1], 'numberposts' => 1, 'post_status' => 'inherit' ) );
		$img[ $klucz ] = $a ? $a[0]->ID : 0;
	}
	$html = file_get_contents( get_template_directory() . '/content/home.html' );
	$html = preg_replace_callback( '/\{\{(img|id):([a-z0-9-]+)\}\}/', function ( $m ) use ( $img ) {
		$id = $img[ $m[2] ] ?? 0;
		return 'img' === $m[1] ? wp_get_attachment_image_url( $id, 'full' ) : (string) $id;
	}, $html );
	return wp_update_post( array( 'ID' => (int) get_option( 'page_on_front' ), 'post_content' => $html ) );
}
