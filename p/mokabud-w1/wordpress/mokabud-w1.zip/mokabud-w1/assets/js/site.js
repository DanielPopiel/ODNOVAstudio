/* Mokabud W1 „Etapami” — scena etapów, nagłówek, odsłanianie. Treść pochodzi z bloków WordPressa. */
(function () {
  'use strict';
  var d = document, root = d.documentElement;
  var ruch = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* wysokość nagłówka → odstępy */
  var hdr = d.querySelector('.mb-header');
  function mierz() { if (hdr) root.style.setProperty('--hdr-h', hdr.offsetHeight + 'px'); }
  mierz(); addEventListener('resize', mierz); addEventListener('load', mierz);
  addEventListener('scroll', function () { if (hdr) hdr.classList.toggle('is-przewiniete', scrollY > 40); }, { passive: true });

  /* tabela: „—” przygaszone */
  d.querySelectorAll('.mb-tabela td').forEach(function (td) {
    var t = td.textContent.trim();
    if (t === '—') { td.classList.add('mb-brak'); td.innerHTML = '<span class="screen-reader-text">poza zakresem</span>'; }
    else if (t === '✓') { td.classList.add('mb-tak'); td.innerHTML = '<span class="screen-reader-text">w zakresie</span>'; }
  });
  /* tabela na telefonie: przełącznik zakresów */
  d.querySelectorAll('.mb-tabela').forEach(function (fig) {
    var ths = fig.querySelectorAll('thead th'); if (ths.length < 3) return;
    var bar = d.createElement('div'); bar.className = 'mb-warianty'; bar.setAttribute('role', 'tablist'); bar.setAttribute('aria-label', 'Zakres');
    [].slice.call(ths, 1).forEach(function (th, i) {
      var b = d.createElement('button'); b.type = 'button'; b.setAttribute('role', 'tab'); b.textContent = th.textContent;
      b.addEventListener('click', function () { fig.dataset.kol = i + 2; bar.querySelectorAll('button').forEach(function (x, j) { x.setAttribute('aria-selected', j === i ? 'true' : 'false'); }); });
      bar.appendChild(b);
    });
    fig.parentNode.insertBefore(bar, fig); fig.dataset.kol = 5; bar.lastChild.setAttribute('aria-selected', 'true');
    [].forEach.call(bar.children, function (x, j) { if (j < bar.children.length - 1) x.setAttribute('aria-selected', 'false'); });
    var mq = matchMedia('(max-width: 781px)'); function pokaz() { bar.hidden = !mq.matches; } pokaz(); mq.addEventListener('change', pokaz);
  });

  /* ── scena etapów ── */
  var sek = d.querySelector('.mb-etapy');
  var etapy = sek ? [].slice.call(sek.querySelectorAll('.mb-etap')) : [];
  if (sek && etapy.length > 1 && ruch) {
    var N = etapy.length, WSTEP = 0.6, JEDN = innerWidth < 782 ? 0.55 : 0.7;
    var intro = sek.querySelector('.mb-etapy__intro');
    var scena = d.createElement('div'); scena.className = 'mb-scena';
    var kadry = d.createElement('div'); kadry.className = 'mb-scena__kadry';
    var tresc = d.createElement('div'); tresc.className = 'mb-scena__tresc';
    var podpisy = d.createElement('div'); podpisy.className = 'mb-podpisy';
    var szyna = d.createElement('div'); szyna.className = 'mb-szyna'; szyna.setAttribute('role', 'group'); szyna.setAttribute('aria-label', 'Etapy budowy');
    var figs = [], caps = [], btns = [];
    etapy.forEach(function (e, i) {
      var f = e.querySelector('.mb-etap__kadr'); if (f) { kadry.appendChild(f); figs.push(f); }
      var c = d.createElement('div'); c.className = 'mb-podpis';
      while (e.firstChild) c.appendChild(e.firstChild);
      podpisy.appendChild(c); caps.push(c);
      var n = c.querySelector('.mb-etap__nazwa');
      var b = d.createElement('button'); b.type = 'button';
      b.innerHTML = '<span>' + (i + 1) + '</span>' + (n ? n.textContent.replace(/\s*—.*$/, '') : 'Etap ' + (i + 1));
      b.addEventListener('click', function () {
        var r = sek.getBoundingClientRect(), zakres = sek.offsetHeight - innerHeight;
        var t = WSTEP + i + 0.15, T = WSTEP + N;
        scrollTo({ top: scrollY + r.top + zakres * (t / T), behavior: 'smooth' });
      });
      szyna.appendChild(b); btns.push(b);
    });
    var lista = sek.querySelector('.mb-etapy__lista'); if (lista) lista.remove();
    if (intro) tresc.appendChild(intro);
    var pomin = d.createElement('a'); pomin.className = 'mb-pomin'; pomin.href = '#rozliczenie'; pomin.textContent = 'Pomiń etapy';
    scena.appendChild(kadry); scena.appendChild(tresc); scena.appendChild(podpisy); scena.appendChild(szyna); scena.appendChild(pomin);
    if (hdr) hdr.classList.add('na-scenie');
    sek.appendChild(scena);
    sek.classList.add('is-scena');
    sek.style.setProperty('--etapy', N);
    function wys() { JEDN = innerWidth < 782 ? 0.55 : 0.7; sek.style.height = ((WSTEP + N) * JEDN * innerHeight + innerHeight) + 'px'; }
    wys(); addEventListener('resize', wys);

    var ss = function (a, b, x) { x = Math.min(1, Math.max(0, (x - a) / (b - a))); return x * x * (3 - 2 * x); };
    var ostatni = -1, ramka = 0;
    function rysuj() {
      ramka = 0;
      var r = sek.getBoundingClientRect(), zakres = sek.offsetHeight - innerHeight;
      var p = Math.min(1, Math.max(0, -r.top / zakres));
      var t = p * (WSTEP + N), u = Math.max(0, t - WSTEP);
      var idx = Math.min(N - 1, Math.floor(u));
      figs.forEach(function (f, i) {
        var o = i === 0 ? 1 : ss(i - 0.32, i + 0.02, u);
        f.style.opacity = o;
      });
      kadry.style.setProperty('--z', (1.06 - 0.06 * p).toFixed(4));
      if (intro) intro.classList.toggle('is-ukryte', t > WSTEP * 0.82);
      var akt = t > WSTEP * 0.82 ? idx : -1;
      if (akt !== ostatni) {
        caps.forEach(function (c, i) { c.classList.toggle('on', i === akt); c.setAttribute('aria-hidden', i === akt ? 'false' : 'true'); });
        ostatni = akt;
      }
      btns.forEach(function (b, i) { b.style.setProperty('--p', Math.min(1, Math.max(0, u - i)).toFixed(3)); b.classList.toggle('on', i === akt); if (i === akt) b.setAttribute('aria-current', 'step'); else b.removeAttribute('aria-current'); });
      if (hdr) hdr.classList.toggle('na-scenie', r.bottom > 80);
      /* wyjście sceny: tekst gaśnie, gdy sekcja odjeżdża */
      var wyj = Math.min(1, Math.max(0, (r.bottom - innerHeight) / (innerHeight * 0.35)));
      tresc.style.opacity = podpisy.style.opacity = wyj.toFixed(3);
    }
    addEventListener('scroll', function () { if (!ramka) ramka = requestAnimationFrame(rysuj); }, { passive: true });
    addEventListener('resize', rysuj);
    rysuj();
  }

  /* ── odsłanianie: tylko nagłówki sekcji i kilka bloków ── */
  var cele = d.querySelectorAll('.mb-sekcja h2, .mb-cytat-wielki, .mb-tabela, .mb-ocena');
  cele.forEach(function (el) { el.classList.add('reveal'); });
  var zadzialal = false;
  if ('IntersectionObserver' in window && ruch) {
    var io = new IntersectionObserver(function (wpisy) {
      wpisy.forEach(function (w) { if (w.isIntersecting) { zadzialal = true; w.target.classList.add('in'); io.unobserve(w.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    cele.forEach(function (el) { io.observe(el); });
    var sweep = function () { cele.forEach(function (el) { if (el.getBoundingClientRect().top < innerHeight) el.classList.add('in'); }); };
    var tm; addEventListener('scroll', function () { clearTimeout(tm); tm = setTimeout(sweep, 140); }, { passive: true });
    setTimeout(function () { if (!zadzialal) cele.forEach(function (el) { el.classList.add('in'); }); }, 4000);
  } else { cele.forEach(function (el) { el.classList.add('in'); }); }
})();
