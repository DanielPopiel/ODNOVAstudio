/* Mokabud W2 „Dziennik budowy” — oddanie kluczy przesuwane przewijaniem, nagłówek, odsłanianie. */
(function () {
  'use strict';
  var d = document, root = d.documentElement;
  var ruch = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var hdr = d.querySelector('.mb-header');
  function mierz() { if (hdr) root.style.setProperty('--hdr-h', hdr.offsetHeight + 'px'); }
  mierz(); addEventListener('resize', mierz); addEventListener('load', mierz);
  addEventListener('scroll', function () { if (hdr) hdr.classList.toggle('is-przewiniete', scrollY > 40); }, { passive: true });

  /* ── hero: oddanie kluczy — przewijanie przesuwa film, ołówek odhacza etapy ── */
  var sek = d.querySelector('.mb-odbior');
  var video = sek && sek.querySelector('.mb-odbior__film video');
  if (sek && video) {
    var scena = sek.querySelector('.mb-odbior__scena');
    var wpisy = [].slice.call(sek.querySelectorAll('.mb-wpisy li'));
    var opis = sek.querySelector('.mb-odbior__opis');
    var licznik = d.createElement('b'); if (opis) opis.appendChild(licznik);
    var podp = d.createElement('p'); podp.className = 'mb-odbior__podpowiedz'; podp.setAttribute('aria-hidden', 'true'); podp.textContent = 'Przewiń';
    scena.appendChild(podp);
    video.muted = true; video.playsInline = true; video.removeAttribute('controls');
    var PROGI = [0.22, 0.52, 0.86];
    var stan = function (p) {
      wpisy.forEach(function (li, i) { li.classList.toggle('on', p >= PROGI[i]); });
      licznik.textContent = Math.min(3, 1 + Math.floor(p * 3)) + '/3';
    };
    if (!ruch) { wpisy.forEach(function (li) { li.classList.add('on'); }); licznik.textContent = '3/3'; }
    else {
      stan(0);
      var przyp = function () { return getComputedStyle(scena).position === 'sticky'; };
      var czas = function () { return video.duration || 10; };
      var cel = 0, teraz = 0, petla = false;
      var krok = function () {
        teraz += (cel - teraz) * 0.18;
        if (Math.abs(cel - teraz) < 0.0015) teraz = cel;
        var t = teraz * (czas() - 0.05);
        if (Math.abs(video.currentTime - t) > 1 / 60 && !video.seeking) video.currentTime = t;
        stan(teraz);
        if (teraz !== cel) requestAnimationFrame(krok); else petla = false;
      };
      var przewin = function () {
        if (!przyp()) return;
        var r = sek.getBoundingClientRect();
        cel = Math.min(1, Math.max(0, -r.top / Math.max(1, sek.offsetHeight - scena.offsetHeight)));
        sek.classList.toggle('is-przewijane', cel > 0.02);
        if (!petla) { petla = true; requestAnimationFrame(krok); }
      };
      addEventListener('scroll', przewin, { passive: true });
      addEventListener('resize', przewin);
      video.addEventListener('loadedmetadata', przewin);
      przewin();
      /* telefon: film gra raz, gdy wjedzie na ekran */
      var zagrany = false;
      video.addEventListener('timeupdate', function () { if (!przyp()) stan(video.currentTime / czas()); });
      if ('IntersectionObserver' in window) {
        new IntersectionObserver(function (e) {
          if (przyp()) return;
          if (e[0].isIntersecting && !zagrany) { zagrany = true; var pr = video.play(); if (pr && pr.catch) pr.catch(function () {}); }
        }, { threshold: 0.55 }).observe(sek.querySelector('.mb-odbior__kadr'));
      }
    }
  }

  /* ── harmonogram: tabela z bloku → wykres Gantta przewijany ── */
  d.querySelectorAll('figure.mb-harmonogram').forEach(function (fig) {
    var rows = [].slice.call(fig.querySelectorAll('tbody tr')).map(function (tr) {
      var c = tr.querySelectorAll('td'); if (c.length < 4) return null;
      var w = c[1].textContent.match(/(\d+)\s*[–-]\s*(\d+)/); if (!w) return null;
      return { n: c[0].textContent.trim(), a: +w[1] - 1, b: +w[2], o: c[2].textContent.trim(), p: c[3].textContent.trim() };
    }).filter(Boolean);
    if (rows.length < 2) return;
    var W = Math.max.apply(null, rows.map(function (r) { return r.b; }));
    var wrap = d.createElement('div'); wrap.className = 'mb-gantt-wrap'; wrap.style.position = 'relative';
    var os = d.createElement('div'); os.className = 'mb-gantt__os'; os.setAttribute('aria-hidden', 'true');
    var sk = '<span></span><div class="mb-gantt__skala">';
    for (var t = 0; t <= W; t += 4) sk += '<span style="left:' + (t / W * 100) + '%">' + (t === 0 ? 'tydz. 0' : t) + '</span>';
    os.innerHTML = sk + '</div>';
    var ol = d.createElement('ol'); ol.className = 'mb-gantt'; ol.style.setProperty('--W', W);
    rows.forEach(function (r, i) {
      var li = d.createElement('li');
      var plat = i === 0 ? r.p : 'faktura ' + r.p.replace(/^po /, 'po ');
      li.innerHTML = '<span class="mb-gantt__nazwa"></span><span class="mb-gantt__tor"><span class="mb-gantt__belka" style="--a:' + r.a + ';--b:' + r.b + '"></span><span class="mb-gantt__plat" style="--b:' + r.b + '"><span></span></span></span>';
      li.querySelector('.mb-gantt__nazwa').textContent = r.n;
      li.querySelector('.mb-gantt__plat span').textContent = plat;
      li.setAttribute('aria-label', r.n + ', tygodnie ' + (r.a + 1) + '–' + r.b + ', odbiór: ' + r.o + ', płatność: ' + r.p);
      li.style.setProperty('--W', W); if (r.b / W > 0.75) li.classList.add('plat-lewo');
      ol.appendChild(li); r.el = li; r.bar = li.querySelector('.mb-gantt__belka');
    });
    var kursor = d.createElement('div'); kursor.className = 'mb-gantt__kursor'; kursor.setAttribute('aria-hidden', 'true'); kursor.innerHTML = '<span></span>';
    wrap.appendChild(os); wrap.appendChild(ol); wrap.appendChild(kursor);
    fig.insertBefore(wrap, fig.firstChild); fig.classList.add('is-gantt');
    function gantt() {
      var r = ol.getBoundingClientRect();
      var p = ruch ? Math.min(1, Math.max(0, (innerHeight * 0.85 - r.top) / (r.height + innerHeight * 0.35))) : 1;
      var wk = p * W * 1.04;
      rows.forEach(function (x) { var f = Math.min(1, Math.max(0, (wk - x.a) / (x.b - x.a))); x.bar.style.setProperty('--f', f.toFixed(3)); x.el.classList.toggle('on', f >= 1); });
      var k = Math.min(1, wk / W); kursor.style.setProperty('--k', k.toFixed(4));
      kursor.style.opacity = p > 0 && p < 1 ? 1 : 0; kursor.classList.toggle('lewo', k > 0.7);
      kursor.firstChild.textContent = 'tydzień ' + Math.max(1, Math.round(Math.min(W, wk)));
    }
    var rr = 0; addEventListener('scroll', function () { if (!rr) rr = requestAnimationFrame(function () { rr = 0; gantt(); }); }, { passive: true });
    addEventListener('resize', gantt); gantt();
  });

  /* ── miarka: postęp strony jako wysokość domu (±0,00 → +7,10 m) ── */
  if (matchMedia('(min-width: 1280px)').matches) {
    var mi = d.createElement('div'); mi.className = 'mb-miarka'; mi.setAttribute('aria-hidden', 'true'); mi.innerHTML = '<b></b><span></span>';
    d.body.appendChild(mi);
    var miT = mi.querySelector('span'), mr = 0;
    var miarka = function () { mr = 0; var m = Math.min(1, Math.max(0, scrollY / (d.documentElement.scrollHeight - innerHeight))); mi.style.setProperty('--m', m.toFixed(4)); var h = m * 7.1; miT.textContent = (h < 0.005 ? '±0,00' : '+' + h.toFixed(2).replace('.', ',')) + ' m'; var el = d.elementFromPoint(60, innerHeight * (1 - m) * 0.9 + 40); mi.classList.toggle('na-ciemnym', !!(el && el.closest('.mb-ciemna, .mb-footer'))); };
    addEventListener('scroll', function () { if (!mr) mr = requestAnimationFrame(miarka); }, { passive: true }); miarka();
  }

  /* ── odsłanianie ── */
  var cele = d.querySelectorAll('.mb-sekcja h2, .mb-schody, .mb-ocena');
  cele.forEach(function (el) { el.classList.add('reveal'); });
  var zadzialal = false;
  if ('IntersectionObserver' in window && ruch) {
    var io = new IntersectionObserver(function (w) { w.forEach(function (x) { if (x.isIntersecting) { zadzialal = true; x.target.classList.add('in'); io.unobserve(x.target); } }); }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    cele.forEach(function (el) { io.observe(el); });
    var tm; addEventListener('scroll', function () { clearTimeout(tm); tm = setTimeout(function () { cele.forEach(function (el) { if (el.getBoundingClientRect().top < innerHeight) el.classList.add('in'); }); }, 140); }, { passive: true });
    setTimeout(function () { if (!zadzialal) cele.forEach(function (el) { el.classList.add('in'); }); }, 4000);
  } else { cele.forEach(function (el) { el.classList.add('in'); }); }
})();
