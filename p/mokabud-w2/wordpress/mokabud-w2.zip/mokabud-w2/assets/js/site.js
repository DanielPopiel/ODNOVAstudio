/* Mokabud W2 „Dziennik budowy” — przekrój domu rysowany przy przewijaniu, nagłówek, odsłanianie. */
(function () {
  'use strict';
  var d = document, root = d.documentElement;
  var ruch = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var hdr = d.querySelector('.mb-header');
  function mierz() { if (hdr) root.style.setProperty('--hdr-h', hdr.offsetHeight + 'px'); }
  mierz(); addEventListener('resize', mierz); addEventListener('load', mierz);
  addEventListener('scroll', function () { if (hdr) hdr.classList.toggle('is-przewiniete', scrollY > 40); }, { passive: true });

  /* ── przekrój ── */
  var sek = d.querySelector('.mb-przekroj');
  var foto = sek && sek.querySelector('.mb-przekroj__foto');
  if (sek && foto) {
    var NS = 'http://www.w3.org/2000/svg';
    /* rysunek: [grupa, ścieżka, klasa] — grupy zapalają się po kolei; t = przekrój (gruba kreska, kreskowanie) */
    var linie = [
      [0, 'M60 470H760'],
      [0, 'M60 470H140V486H60ZM660 470H760V486H660Z', 'g'],
      [1, 'M150 452H650V478H150Z', 't'],
      [1, 'M138 482H662', 'c'],
      [2, 'M160 300H184V330H160ZM160 410H184V452H160ZM616 300H640V330H616ZM616 410H640V452H616Z', 't'],
      [2, 'M172 330V410M628 330V410'],
      [2, 'M396 452V300M404 452V300'],
      [3, 'M150 284H650V300H150Z', 't'],
      [3, 'M420 452' + 'v-19h22'.repeat(8)],
      [3, 'M160 284V258H184V284ZM616 284V258H640V284Z', 't'],
      [4, 'M110 292L400 112L690 292', 'tl'],
      [4, 'M138 292L400 130L662 292'],
      [5, 'M720 452V112M664 452H728M664 292H728M404 112H728M714 458l12-12M714 298l12-12M714 118l12-12', 'c'],
      [5, 'M150 510H650M150 484V516M650 484V516M144 516l12-12M644 516l12-12', 'c']
    ];
    var napisy = [
      [1, 196, 500, 'płyta fundamentowa 25 cm'],
      [2, 196, 352, 'ściana 25 cm + EPS 20 cm'],
      [3, 424, 276, 'strop monolityczny 20 cm', 'r'],
      [4, 372, 214, 'więźba'],
      [5, 734, 457, '±0,00'],
      [5, 734, 297, '+2,80'],
      [5, 734, 117, '+7,10'],
      [5, 364, 534, '10,40 m']
    ];
    var ETAPY = ['2 z 5 — płyta fundamentowa', '3 z 5 — mury', '4 z 5 — strop i schody', '5 z 5 — dach', 'stan surowy odebrany'];
    var svg = d.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '50 70 730 548'); svg.setAttribute('class', 'mb-rys'); svg.setAttribute('aria-hidden', 'true');
    svg.innerHTML = '<defs><pattern id="mb-kresk" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0V7" stroke="#16202B" stroke-width="1"/></pattern>'
      + '<pattern id="mb-grunt" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(-45)"><path d="M0 0V6" stroke="#16202B" stroke-width=".8"/></pattern></defs>';
    var sciezki = linie.map(function (l) {
      var p = d.createElementNS(NS, 'path'); p.setAttribute('d', l[1]); p.setAttribute('class', 'l ' + (l[2] || '')); p.setAttribute('pathLength', '1');
      p.style.strokeDasharray = '1 1'; p.style.strokeDashoffset = '1'; svg.appendChild(p); return { g: l[0], el: p, fill: /^(t|g)$/.test(l[2] || '') };
    });
    var teksty = napisy.map(function (n) {
      var t = d.createElementNS(NS, 'text'); t.setAttribute('x', n[1]); t.setAttribute('y', n[2]); t.textContent = n[3]; if (n[4]) t.setAttribute('class', n[4]); svg.appendChild(t); return { g: n[0], el: t };
    });
    var ark = d.createElement('div'); ark.className = 'mb-arkusz';
    foto.parentNode.insertBefore(ark, foto); ark.appendChild(foto); ark.appendChild(svg);
    var tab = d.createElement('div'); tab.className = 'mb-arkusz__tab';
    tab.innerHTML = '<span>Obiekt</span><span>Dom jednorodzinny</span><span>Etap</span><span class="mb-tab-etap">' + ETAPY[0] + '</span><span>Odbiór</span><span>kierownik budowy</span><span>Skala</span><span class="num">1:100</span>';
    ark.appendChild(tab);
    var tabEtap = tab.querySelector('.mb-tab-etap');
    var podp = d.createElement('div'); podp.className = 'mb-arkusz__podpis';
    podp.innerHTML = '<span>Przekrój A–A, dom parterowy z poddaszem</span>';
    ark.appendChild(podp);
    var podpTxt = podp.firstChild;
    var wpisy = [].slice.call(sek.querySelectorAll('.mb-wpisy li'));
    sek.classList.add('is-rys');

    var desktop = matchMedia('(min-width: 981px)');
    var pin = null;
    function ustaw() {
      if (desktop.matches && ruch && !pin) {
        pin = d.createElement('div'); pin.className = 'mb-przekroj__pin';
        while (sek.firstChild) pin.appendChild(sek.firstChild);
        sek.appendChild(pin); sek.classList.add('is-sticky');
      } else if ((!desktop.matches || !ruch) && pin) {
        while (pin.firstChild) sek.appendChild(pin.firstChild);
        pin.remove(); pin = null; sek.classList.remove('is-sticky');
      }
    }
    ustaw(); desktop.addEventListener('change', function () { ustaw(); rysuj(); });

    var G = 6, G0 = 2.4, ramka = 0, auto = null, reczny = null, ostatniP = 0, yReczny = 0;
    /* suwak: rysunek | zdjęcie (przeciągnij) */
    var suwak = d.createElement('button'); suwak.type = 'button'; suwak.className = 'mb-suwak';
    suwak.setAttribute('role', 'slider'); suwak.setAttribute('aria-label', 'Porównaj rysunek ze zdjęciem'); suwak.setAttribute('aria-valuemin', '0'); suwak.setAttribute('aria-valuemax', '100');
    ark.appendChild(suwak);
    function ustawRecznie(x) { reczny = Math.min(1, Math.max(0, x)); yReczny = scrollY; stan(Math.max(ostatniP, 0.62)); }
    suwak.addEventListener('pointerdown', function (e) {
      e.preventDefault(); suwak.setPointerCapture(e.pointerId);
      function ruchP(ev) { var r = ark.getBoundingClientRect(); ustawRecznie((ev.clientX - r.left) / r.width); }
      function koniec() { suwak.removeEventListener('pointermove', ruchP); suwak.removeEventListener('pointerup', koniec); }
      suwak.addEventListener('pointermove', ruchP); suwak.addEventListener('pointerup', koniec);
    });
    suwak.addEventListener('keydown', function (e) {
      var f = reczny !== null ? reczny : parseFloat(ark.style.getPropertyValue('--foto')) || 0;
      if (e.key === 'ArrowLeft') { ustawRecznie(f - 0.05); e.preventDefault(); }
      if (e.key === 'ArrowRight') { ustawRecznie(f + 0.05); e.preventDefault(); }
    });
    /* krzyż kreślarski: współrzędne w metrach na rysunku */
    var krzyz = d.createElement('div'); krzyz.className = 'mb-krzyz'; krzyz.setAttribute('aria-hidden', 'true'); krzyz.innerHTML = '<span></span>';
    ark.appendChild(krzyz);
    var krzyzTxt = krzyz.firstChild;
    if (matchMedia('(pointer: fine)').matches) {
      ark.addEventListener('pointermove', function (e) {
        if (e.target === suwak) { ark.classList.remove('is-krzyz'); return; }
        var r = ark.getBoundingClientRect(), fx = (e.clientX - r.left) / r.width;
        var f = parseFloat(ark.style.getPropertyValue('--foto')) || 0;
        if (fx < f) { ark.classList.remove('is-krzyz'); return; }       // nad zdjęciem — bez krzyża
        var m = svg.getScreenCTM(); if (!m) return;
        var pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; var v = pt.matrixTransform(m.inverse());
        var xm = (v.x - 150) * 10.4 / 500, hm = (452 - v.y) * 7.1 / 340;
        krzyz.style.setProperty('--cx', (e.clientX - r.left) + 'px'); krzyz.style.setProperty('--cy', (e.clientY - r.top) + 'px');
        krzyzTxt.textContent = 'x ' + xm.toFixed(2).replace('.', ',') + ' m · h ' + (hm >= 0 ? '+' : '−') + Math.abs(hm).toFixed(2).replace('.', ',') + ' m';
        ark.classList.add('is-krzyz');
      });
      ark.addEventListener('pointerleave', function () { ark.classList.remove('is-krzyz'); });
    }
    function stan(p) {
      var rys = Math.min(1, p / 0.62);                     // 0–62%: rysowanie
      var g = G0 + rys * (G - G0);                          // fundament i mury od pierwszej klatki
      sciezki.forEach(function (s) { var x = Math.min(1, Math.max(0, g - s.g)); s.el.style.strokeDashoffset = (1 - x).toFixed(3); s.el.classList.toggle('on', s.fill && x > 0.92); });
      teksty.forEach(function (t) { t.el.classList.toggle('on', g > t.g + 0.55); });
      var f = Math.min(1, Math.max(0, (p - 0.62) / 0.28));   // 62–90%: zdjęcie wjeżdża jak przesłona
      if (reczny !== null) f = reczny;
      ark.style.setProperty('--foto', f.toFixed(4));
      svg.style.clipPath = 'inset(0 0 0 ' + (f * 100).toFixed(2) + '%)';
      ark.classList.toggle('is-suwak', f > 0.02);
      suwak.setAttribute('aria-valuenow', Math.round(f * 100));
      tab.style.clipPath = svg.style.clipPath;
      tabEtap.textContent = ETAPY[Math.max(0, Math.min(ETAPY.length - 1, Math.floor(g) - 1))];
      podpTxt.textContent = f > 0.95 ? 'Ten sam dom po odbiorze końcowym' : 'Przekrój A–A, dom parterowy z poddaszem';
      wpisy.forEach(function (li, i) { li.classList.toggle('on', g >= [2.4, 3.9, 5.0][i]); });
    }
    function rysuj() {
      ramka = 0;
      if (!ruch) return stan(1);
      if (reczny !== null && Math.abs(scrollY - yReczny) > 80) reczny = null;
      if (pin) { var r = sek.getBoundingClientRect(); ostatniP = Math.min(1, Math.max(0, -r.top / (sek.offsetHeight - innerHeight))); return stan(ostatniP); }
      if (auto === null) stan(0);
    }
    /* telefon: rysunek rusza sam, gdy arkusz wjedzie na ekran */
    if (ruch && 'IntersectionObserver' in window) {
      var obs = new IntersectionObserver(function (w) {
        if (pin || !w[0].isIntersecting || auto !== null) return;
        var t0 = performance.now(); auto = 0;
        (function krok(t) { auto = Math.min(1, (t - t0) / 3600); ostatniP = auto; if (reczny === null) stan(auto); if (auto < 1 && !pin) requestAnimationFrame(krok); })(t0);
        obs.disconnect();
      }, { threshold: 0.55 });
      obs.observe(ark);
    }
    addEventListener('scroll', function () { if (!ramka) ramka = requestAnimationFrame(rysuj); }, { passive: true });
    addEventListener('resize', rysuj); rysuj();
  }

  /* ── harmonogram: tabela z bloku → wykres Gantta przewijany ── */
  d.querySelectorAll('figure.mb-harmonogram').forEach(function (fig) {
    var rows = [].slice.call(fig.querySelectorAll('tbody tr')).map(function (tr) {
      var c = tr.querySelectorAll('td'); if (c.length < 4) return null;
      var w = c[1].textContent.match(/(\d+)\s*[–-]\s*(\d+)/); if (!w) return null;
      return { n: c[0].textContent.trim(), a: +w[1] - 1, b: +w[2], o: c[2].textContent.trim(), p: c[3].textContent.trim() };
    }).filter(Boolean);
    if (rows.length < 2) return;
    var W = Math.max.apply(null, rows.map(function (r) { return r.b; }));
    var wrap = d.createElement('div'); wrap.className = 'mb-gantt-wrap'; wrap.style.position = 'relative';
    var os = d.createElement('div'); os.className = 'mb-gantt__os'; os.setAttribute('aria-hidden', 'true');
    var sk = '<span></span><div class="mb-gantt__skala">';
    for (var t = 0; t <= W; t += 4) sk += '<span style="left:' + (t / W * 100) + '%">' + (t === 0 ? 'tydz. 0' : t) + '</span>';
    os.innerHTML = sk + '</div>';
    var ol = d.createElement('ol'); ol.className = 'mb-gantt'; ol.style.setProperty('--W', W);
    rows.forEach(function (r, i) {
      var li = d.createElement('li');
      var plat = i === 0 ? r.p : 'faktura ' + r.p.replace(/^po /, 'po ');
      li.innerHTML = '<span class="mb-gantt__nazwa"></span><span class="mb-gantt__tor"><span class="mb-gantt__belka" style="--a:' + r.a + ';--b:' + r.b + '"></span><span class="mb-gantt__plat" style="--b:' + r.b + '"><span></span></span></span>';
      li.querySelector('.mb-gantt__nazwa').textContent = r.n;
      li.querySelector('.mb-gantt__plat span').textContent = plat;
      li.setAttribute('aria-label', r.n + ', tygodnie ' + (r.a + 1) + '–' + r.b + ', odbiór: ' + r.o + ', płatność: ' + r.p);
      li.style.setProperty('--W', W); if (r.b / W > 0.75) li.classList.add('plat-lewo');
      ol.appendChild(li); r.el = li; r.bar = li.querySelector('.mb-gantt__belka');
    });
    var kursor = d.createElement('div'); kursor.className = 'mb-gantt__kursor'; kursor.setAttribute('aria-hidden', 'true'); kursor.innerHTML = '<span></span>';
    wrap.appendChild(os); wrap.appendChild(ol); wrap.appendChild(kursor);
    fig.insertBefore(wrap, fig.firstChild); fig.classList.add('is-gantt');
    function gantt() {
      var r = ol.getBoundingClientRect();
      var p = ruch ? Math.min(1, Math.max(0, (innerHeight * 0.85 - r.top) / (r.height + innerHeight * 0.35))) : 1;
      var wk = p * W * 1.04;
      rows.forEach(function (x) { var f = Math.min(1, Math.max(0, (wk - x.a) / (x.b - x.a))); x.bar.style.setProperty('--f', f.toFixed(3)); x.el.classList.toggle('on', f >= 1); });
      var k = Math.min(1, wk / W); kursor.style.setProperty('--k', k.toFixed(4));
      kursor.style.opacity = p > 0 && p < 1 ? 1 : 0; kursor.classList.toggle('lewo', k > 0.7);
      kursor.firstChild.textContent = 'tydzień ' + Math.max(1, Math.round(Math.min(W, wk)));
    }
    var rr = 0; addEventListener('scroll', function () { if (!rr) rr = requestAnimationFrame(function () { rr = 0; gantt(); }); }, { passive: true });
    addEventListener('resize', gantt); gantt();
  });

  /* ── miarka: postęp strony jako wysokość domu (±0,00 → +7,10 m) ── */
  if (matchMedia('(min-width: 1280px)').matches) {
    var mi = d.createElement('div'); mi.className = 'mb-miarka'; mi.setAttribute('aria-hidden', 'true'); mi.innerHTML = '<b></b><span></span>';
    d.body.appendChild(mi);
    var miT = mi.querySelector('span'), mr = 0;
    var miarka = function () { mr = 0; var m = Math.min(1, Math.max(0, scrollY / (d.documentElement.scrollHeight - innerHeight))); mi.style.setProperty('--m', m.toFixed(4)); var h = m * 7.1; miT.textContent = (h < 0.005 ? '±0,00' : '+' + h.toFixed(2).replace('.', ',')) + ' m'; var el = d.elementFromPoint(60, innerHeight * (1 - m) * 0.9 + 40); mi.classList.toggle('na-ciemnym', !!(el && el.closest('.mb-ciemna, .mb-footer'))); };
    addEventListener('scroll', function () { if (!mr) mr = requestAnimationFrame(miarka); }, { passive: true }); miarka();
  }

  /* ── odsłanianie ── */
  var cele = d.querySelectorAll('.mb-sekcja h2, .mb-schody, .mb-ocena');
  cele.forEach(function (el) { el.classList.add('reveal'); });
  var zadzialal = false;
  if ('IntersectionObserver' in window && ruch) {
    var io = new IntersectionObserver(function (w) { w.forEach(function (x) { if (x.isIntersecting) { zadzialal = true; x.target.classList.add('in'); io.unobserve(x.target); } }); }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    cele.forEach(function (el) { io.observe(el); });
    var tm; addEventListener('scroll', function () { clearTimeout(tm); tm = setTimeout(function () { cele.forEach(function (el) { if (el.getBoundingClientRect().top < innerHeight) el.classList.add('in'); }); }, 140); }, { passive: true });
    setTimeout(function () { if (!zadzialal) cele.forEach(function (el) { el.classList.add('in'); }); }, 4000);
  } else { cele.forEach(function (el) { el.classList.add('in'); }); }
})();
