/* Mokabud W2 „Dziennik budowy” — przekrój domu rysowany przy przewijaniu, nagłówek, odsłanianie. */
(function () {
  'use strict';
  var d = document, root = d.documentElement;
  var ruch = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var hdr = d.querySelector('.mb-header');
  function mierz() { if (hdr) root.style.setProperty('--hdr-h', hdr.offsetHeight + 'px'); }
  mierz(); addEventListener('resize', mierz); addEventListener('load', mierz);
  addEventListener('scroll', function () { if (hdr) hdr.classList.toggle('is-przewiniete', scrollY > 40); }, { passive: true });

  /* ── przekrój ── */
  var sek = d.querySelector('.mb-przekroj');
  var foto = sek && sek.querySelector('.mb-przekroj__foto');
  if (sek && foto) {
    var NS = 'http://www.w3.org/2000/svg';
    /* rysunek: [grupa, ścieżka, klasa] — grupy zapalają się po kolei; t = przekrój (gruba kreska, kreskowanie) */
    var linie = [
      [0, 'M60 470H760'],
      [0, 'M60 470H140V486H60ZM660 470H760V486H660Z', 'g'],
      [1, 'M150 452H650V478H150Z', 't'],
      [1, 'M138 482H662', 'c'],
      [2, 'M160 300H184V330H160ZM160 410H184V452H160ZM616 300H640V330H616ZM616 410H640V452H616Z', 't'],
      [2, 'M172 330V410M628 330V410'],
      [2, 'M396 452V300M404 452V300'],
      [3, 'M150 284H650V300H150Z', 't'],
      [3, 'M420 452' + 'v-19h22'.repeat(8)],
      [3, 'M160 284V258H184V284ZM616 284V258H640V284Z', 't'],
      [4, 'M110 292L400 112L690 292', 'tl'],
      [4, 'M138 292L400 130L662 292'],
      [5, 'M720 452V112M664 452H728M664 292H728M404 112H728M714 458l12-12M714 298l12-12M714 118l12-12', 'c'],
      [5, 'M150 510H650M150 484V516M650 484V516M144 516l12-12M644 516l12-12', 'c']
    ];
    var napisy = [
      [1, 196, 500, 'płyta fundamentowa 25 cm'],
      [2, 196, 352, 'ściana 25 cm + EPS 20 cm'],
      [3, 424, 276, 'strop monolityczny 20 cm', 'r'],
      [4, 372, 214, 'więźba'],
      [5, 734, 457, '±0,00'],
      [5, 734, 297, '+2,80'],
      [5, 734, 117, '+7,10'],
      [5, 364, 534, '10,40 m']
    ];
    var ETAPY = ['2 z 5 — płyta fundamentowa', '3 z 5 — mury', '4 z 5 — strop i schody', '5 z 5 — dach', 'stan surowy odebrany'];
    var svg = d.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '50 70 730 548'); svg.setAttribute('class', 'mb-rys'); svg.setAttribute('aria-hidden', 'true');
    svg.innerHTML = '<defs><pattern id="mb-kresk" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0V7" stroke="#16202B" stroke-width="1"/></pattern>'
      + '<pattern id="mb-grunt" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(-45)"><path d="M0 0V6" stroke="#16202B" stroke-width=".8"/></pattern></defs>';
    var sciezki = linie.map(function (l) {
      var p = d.createElementNS(NS, 'path'); p.setAttribute('d', l[1]); p.setAttribute('class', 'l ' + (l[2] || '')); p.setAttribute('pathLength', '1');
      p.style.strokeDasharray = '1 1'; p.style.strokeDashoffset = '1'; svg.appendChild(p); return { g: l[0], el: p, fill: /^(t|g)$/.test(l[2] || '') };
    });
    var teksty = napisy.map(function (n) {
      var t = d.createElementNS(NS, 'text'); t.setAttribute('x', n[1]); t.setAttribute('y', n[2]); t.textContent = n[3]; if (n[4]) t.setAttribute('class', n[4]); svg.appendChild(t); return { g: n[0], el: t };
    });
    var ark = d.createElement('div'); ark.className = 'mb-arkusz';
    foto.parentNode.insertBefore(ark, foto); ark.appendChild(foto); ark.appendChild(svg);
    var tab = d.createElement('div'); tab.className = 'mb-arkusz__tab';
    tab.innerHTML = '<span>Obiekt</span><span>Dom jednorodzinny, okolice Łodzi</span><span>Etap</span><span class="mb-tab-etap">' + ETAPY[0] + '</span><span>Odbiór</span><span>kierownik budowy</span><span>Skala</span><span class="num">1:100</span>';
    ark.appendChild(tab);
    var tabEtap = tab.querySelector('.mb-tab-etap');
    var podp = d.createElement('div'); podp.className = 'mb-arkusz__podpis';
    podp.innerHTML = '<span>Przekrój A–A, dom parterowy z poddaszem</span>';
    ark.appendChild(podp);
    var podpTxt = podp.firstChild;
    var wpisy = [].slice.call(sek.querySelectorAll('.mb-wpisy li'));
    sek.classList.add('is-rys');

    var desktop = matchMedia('(min-width: 981px)');
    var pin = null;
    function ustaw() {
      if (desktop.matches && ruch && !pin) {
        pin = d.createElement('div'); pin.className = 'mb-przekroj__pin';
        while (sek.firstChild) pin.appendChild(sek.firstChild);
        sek.appendChild(pin); sek.classList.add('is-sticky');
      } else if ((!desktop.matches || !ruch) && pin) {
        while (pin.firstChild) sek.appendChild(pin.firstChild);
        pin.remove(); pin = null; sek.classList.remove('is-sticky');
      }
    }
    ustaw(); desktop.addEventListener('change', function () { ustaw(); rysuj(); });

    var G = 6, G0 = 2.4, ramka = 0, auto = null;
    function stan(p) {
      var rys = Math.min(1, p / 0.62);                     // 0–62%: rysowanie
      var g = G0 + rys * (G - G0);                          // fundament i mury od pierwszej klatki
      sciezki.forEach(function (s) { var x = Math.min(1, Math.max(0, g - s.g)); s.el.style.strokeDashoffset = (1 - x).toFixed(3); s.el.classList.toggle('on', s.fill && x > 0.92); });
      teksty.forEach(function (t) { t.el.classList.toggle('on', g > t.g + 0.55); });
      var f = Math.min(1, Math.max(0, (p - 0.62) / 0.28));   // 62–90%: zdjęcie wjeżdża jak przesłona
      ark.style.setProperty('--foto', f.toFixed(4));
      svg.style.opacity = (1 - f).toFixed(3);
      tab.style.opacity = (1 - f).toFixed(3);
      tabEtap.textContent = ETAPY[Math.max(0, Math.min(ETAPY.length - 1, Math.floor(g) - 1))];
      podpTxt.textContent = f > 0.95 ? 'Ten sam dom po odbiorze końcowym' : 'Przekrój A–A, dom parterowy z poddaszem';
      wpisy.forEach(function (li, i) { li.classList.toggle('on', g >= [2.4, 3.9, 5.0][i]); });
    }
    function rysuj() {
      ramka = 0;
      if (!ruch) return stan(1);
      if (pin) { var r = sek.getBoundingClientRect(); return stan(Math.min(1, Math.max(0, -r.top / (sek.offsetHeight - innerHeight)))); }
      if (auto === null) stan(0);
    }
    /* telefon: rysunek rusza sam, gdy arkusz wjedzie na ekran */
    if (ruch && 'IntersectionObserver' in window) {
      var obs = new IntersectionObserver(function (w) {
        if (pin || !w[0].isIntersecting || auto !== null) return;
        var t0 = performance.now(); auto = 0;
        (function krok(t) { auto = Math.min(1, (t - t0) / 3600); stan(auto); if (auto < 1 && !pin) requestAnimationFrame(krok); })(t0);
        obs.disconnect();
      }, { threshold: 0.55 });
      obs.observe(ark);
    }
    addEventListener('scroll', function () { if (!ramka) ramka = requestAnimationFrame(rysuj); }, { passive: true });
    addEventListener('resize', rysuj); rysuj();
  }

  /* ── odsłanianie ── */
  var cele = d.querySelectorAll('.mb-sekcja h2, .mb-schody, .mb-ocena');
  cele.forEach(function (el) { el.classList.add('reveal'); });
  var zadzialal = false;
  if ('IntersectionObserver' in window && ruch) {
    var io = new IntersectionObserver(function (w) { w.forEach(function (x) { if (x.isIntersecting) { zadzialal = true; x.target.classList.add('in'); io.unobserve(x.target); } }); }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    cele.forEach(function (el) { io.observe(el); });
    var tm; addEventListener('scroll', function () { clearTimeout(tm); tm = setTimeout(function () { cele.forEach(function (el) { if (el.getBoundingClientRect().top < innerHeight) el.classList.add('in'); }); }, 140); }, { passive: true });
    setTimeout(function () { if (!zadzialal) cele.forEach(function (el) { el.classList.add('in'); }); }, 4000);
  } else { cele.forEach(function (el) { el.classList.add('in'); }); }
})();
